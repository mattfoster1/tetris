/*To do:
	- Generate grid in the dom ("main_grid")
		- Using a for loop with incremented numbers
		- will need to use an 'attribute selector' in css
	
	- Movement:
		- user to be able to move pieces L/R
		- user to be able to rotate pieces CW/CCW
		
	- Make a counter (for movement beats / rate of play)
		- Pieces move every beat
		- Pieces stop when their bottom edge touches something
			- Another piece, or the bottom
	Line disappears when 
	
	- Define piece shapes
	- Random piece generater
		- should have a 'next piece preview', so have the generator take a step back

	- Scoreboard (every line cleared)

*/


var arraySet1 = new Array(10); //new array with ten undefined elements
var gameTime = 0;
var interval;
var xAxis;
var yAxis;


var setUpGrid = function() {
	// for (var i = 0; i < 10; i++) {
	//   arraySet1[i] = new Array(22); //adds an array with 22 values in each
	// };

	for (xAxis = 0; xAxis < 10; xAxis++) {  // Gives everything in array a value of 0
		for (yAxis = 0; yAxis < 22; yAxis++) {
			arraySet1[xAxis,yAxis] = "0";
			// console.dir(arraySet1[xAxis][yAxis]);
			// console.log(arraySet1[xAxis,yAxis] + " " + xAxis + ", " + yAxis);
			// console.log("xAxis = " + xAxis + ", yAxis =" + yAxis)
		};
	};
	arraySet1[1,1] = "1";
	console.log(arraySet1[1,1]);
}

var fillOutGrid = function() {
	// console.dir(arraySet1);
	var toAdd = document.getElementById("addtohtml1");
	for (var xAxis = 0; xAxis < 10; xAxis++) {
		for (var yAxis = 0; yAxis < 22; yAxis++) { // xAxis === x , yAxis === y
			// console.log(arraySet1[xAxis,yAxis]);
			
			var toAddChild = document.createElement("div" + xAxis);
			toAddChild.id = "cell x"+ xAxis + ", y" + yAxis;
			toAddChild.className = "trial1";
			toAddChild.style.left = xAxis*21 + 'px';
			toAddChild.style.top = yAxis*21 + 'px';
			// document.getElementById("cell x0, y0").innerHTML += "0";
			
			if (arraySet1[xAxis,yAxis] === "1") {
				toAddChild.className = "trial2";

			} else {
				//null
				// var interval = setInterval(function(){document.getElementById("cell x" + xAxis + ", y" + yAxis).innerHTML = "b";}, 1000);
				// document.getElementById("cell x0, y0").innerHTML = "b";
			}

			toAdd.appendChild(toAddChild); //applies it all!
			
			// console.log(yAxis);
			
		}
	}
	console.log(addtohtml1)
}


var theBeat = function() {
	
	if (gameTime < 3) {

	gameTime++;
	document.getElementById("timer").innerHTML = "Game time = " + gameTime;
	fillOutGrid();
	
	};
	

	// console.log("gameTime = " + gameTime);
}

var start = function() {
	setUpGrid();
	randomShapeGenerator();
	var interval = setInterval(function(){theBeat();}, 1000);
	// fillOutGrid();
	

}

var randomShapeGenerator = function() {
	setTimeout(function(){ shapeL(); }, 1200);

	//TASK: assign each shape a number, generate random number, match number to shape, display shape
	//TASK: Generate new shape before previous one lands, for preview window
}

var shapeL = function() {
	console.log(arraySet1[1][1]);
	arraySet1[0][0] = "1";
	
	// toAdd.innerHTML = "b";


	console.log(arraySet1[0][0]);
	console.log(arraySet1[1][0]);
	console.log(arraySet1[2][0]);

	console.log(arraySet1[0][1]);
	console.log(arraySet1[1][1]);
	console.log(arraySet1[2][1]);	

	console.log(arraySet1[0][2]);
	console.log(arraySet1[1][2]);
	console.log(arraySet1[2][2]);

	console.log("x" + xAxis);
	console.log("y" + yAxis);

// 	function editorCreateModel3DTemplate( 10, 22, zzz ){
//     var arr3d = [];
//     for (var z=0; z<zzz; z++){
//         var arr2d = [];
//         for (var y=0; y<yyy; y++){
//             var arr1d = [];
//             for (var x=0; x<xxx; x++){
//                 arr1d.push('aaa');
//             }
//             arr2d.push(arr1d);
//         }
//         arr3d.push(arr2d);
//     }
//     return(arr3d);
// }
	
	// console.log(arraySet1[0,0]);
	// console.log(arraySet1[1,0]);
	// console.log(arraySet1[2,0]);

	// console.log(arraySet1[0,1]);
	// console.log(arraySet1[1,1]);
	// console.log(arraySet1[2,1]);	

	// console.log(arraySet1[0,2]);
	// console.log(arraySet1[1,2]);
	// console.log(arraySet1[2,2]);

	console.dir("a = " + arraySet1[6,6]);
}






 // var array1 = [0,0,0,0,0,0,0,0,0,0], [0,0,0,0,0,0,0,0,0,0], [0,0,0,0,0,0,0,0,0,0];



 console.dir(arraySet1);
