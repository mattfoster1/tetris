/*To do:
	- Generate grid in the dom ("main_grid")
		- Using a for loop with incremented numbers
		- will need to use an 'attribute selector' in css
	
	- Movement:
		- user to be able to move pieces L/R
		- user to be able to rotate pieces CW/CCW
		
	- Make a counter (for movement beats / rate of play)
		- Pieces move every beat
		- Pieces stop when their bottom edge touches something
			- Another piece, or the bottom
	Line disappears when 
	
	- Define piece shapes
	- Random piece generater
		- should have a 'next piece preview', so have the generator take a step back

	- Scoreboard (every line cleared)

	NB keycodes(w===87, a===65, s===83, d===68)

*/


var arraySet1 = []; //new array with ten undefined elements
// console.dir(arraySet1);
var gameTime = 0;
var interval;
var xAxis;
var yAxis;
var arrivalTime;
var livePieceTime = 0;
var vert = livePieceTime;
var horiz = 4;
livePieceOnBoard = 0;
var livePieceShape;
var position1v = [];


var setUpGrid = function() {
	// for (var i = 0; i < 10; i++) {
	//   arraySet1[i] = new Array(22); //adds an array with 22 values in each
	// };

	for (xAxis = 0; xAxis < 10; xAxis++) {  // Gives everything in array a value of 0
		var arraySet0 = [];
		for (yAxis = 0; yAxis < 22; yAxis++) {
			// arraySet1[xAxis] += new Array(1);
			// arraySet1[xAxis,yAxis] = 0;
			
			// console.log(arraySet0);
			arraySet0.push(0)
			
		};

		arraySet1.push(arraySet0); //ERROR - why is this only getting one instance of arraySet0, rather than 10?
		// console.log(arraySet1.length);

		// console.log(arraySet1);
		// console.log(arraySet1[xAxis][yAxis]);
	};
	
	// var ggg = arraySet1.length;
	// console.log(arraySet1[3].length)

}

var fillOutGrid = function() {
	// console.dir(arraySet1);
	var toAdd = document.getElementById("addtohtml1");
	for (var xAxis = 0; xAxis < 10; xAxis++) {
		for (var yAxis = 0; yAxis < 22; yAxis++) { // xAxis === x , yAxis === y
			// console.log(arraySet1[xAxis,yAxis]);
			
			var toAddChild = document.createElement("div" + xAxis);
			toAddChild.id = "cell x"+ xAxis + ", y" + yAxis;
			toAddChild.className = "trial1";
			toAddChild.style.left = xAxis*21 + 'px';
			toAddChild.style.top = yAxis*21 + 'px';
			// document.getElementById("cell x0, y0").innerHTML += 0;
			
			if (arraySet1[xAxis][yAxis] === 1) {
				toAddChild.className = "trial2";

			} else if (arraySet1[xAxis][yAxis] === 2){
				toAddChild.className = "trial3";
				console.log("One made Yellow " + horiz + vert);

			} else {
				//null
					// var interval = setInterval(function(){document.getElementById("cell x" + xAxis + ", y" + yAxis).innerHTML = "b";}, 1000);
					// document.getElementById("cell x0, y0").innerHTML = "b";
			}

			toAdd.appendChild(toAddChild); //applies it all!
			
			// console.log(yAxis);
			
		}
	}

	if (livePieceShape === "L") {
		shapeL();
	}

}


var theBeat = function() {

	if (gameTime < 10) {

	gameTime++;
	document.getElementById("timer").innerHTML = "Game time = " + gameTime;
	// document.getElementById("piecetimer").innerHTML = "Piece time = " + livePieceTime;
	// console.log("livePieceTime = " + livePieceTime);
	livePiecePosition();
	fillOutGrid();
	

		if (livePieceOnBoard === 0) {

			randomShapeGenerator();
		}
	
	};
	

	// console.log("gameTime = " + gameTime);
}

var start = function() {
	setUpGrid();
	var interval = setInterval(function(){theBeat();}, 1000);
	// fillOutGrid();
	

}

var randomShapeGenerator = function() {
	// console.log("NOTIFICATION: randomShapeGenerator triggered");
	livePieceOnBoard = 1;
	
	var arrivalTime = gameTime;
	console.log("GT " + gameTime);
	console.log("AT " + arrivalTime);
	shapeL(); //NOTE: just for now

	//TASK: assign each shape a number, generate random number, match number to shape, display shape
	//TASK: Generate new shape before previous one lands, for preview window
	// setTimeout(function(){ shapeL(); }, 1200);
}

var livePiecePosition = function() {
	// console.log("NOTIFICATION: lastPiecePosition triggered");
	
	if (livePieceOnBoard === 0) {
		livePieceTime = 0;
		console.log("NOTIFICATION - live piece is dead");
	}

	livePieceTime++

	vert = livePieceTime;
	// console.log("verty " + vert);
	// console.log("vert = " + vert + " & AT = " + arrivalTime + " & GT = " + gameTime);
	
	

}


var shapeL = function() {
	livePieceShape = "L";
	// console.log("v = " + vert);
	
	arraySet1[horiz][vert] = 1;
	arraySet1[horiz][vert+1] = 1;
	console.log(arraySet1[horiz][vert]);
	arraySet1[horiz][vert+2] = 1;
	arraySet1[horiz+1][vert+2] = 1;

	var h1 = horiz;
	var v1 = vert;
	var h2 = horiz;
	var v2 = vert+1;
	var h3 = horiz;
	var v3 = vert+2;
	var h4 = horiz+1;
	var v4 = vert+2;

	setTimeout(function(){setInterval(function(){arraySet1[h1][v1] = 0;}, 1000);}, 500);
	// setTimeout(function(){setInterval(function(){arraySet1[h2][v2] = 0;}, 1000);}, 500);
	// setTimeout(function(){setInterval(function(){arraySet1[h3][v3] = 0;}, 1000);}, 500);
	setTimeout(function(){setInterval(function(){arraySet1[h4][v4] = 0;}, 1000);}, 500);
	
	// position1v.push()
	


	// console.log

	// arraySet1[horiz][1] = 1;
	// arraySet1[horiz][2] = 1;
	// arraySet1[horiz][2] = 1;

	// console.log("Is = " + arraySet1[1][1] + " and next to = " + arraySet1[2][1]);
	// console.log("x = " + xAxis + " and y = " + yAxis);
	// console.log();

	// console.log(arraySet1[0][0] + arraySet1[1][0] + arraySet1[2][0]);
	// console.log(arraySet1[0][1] + arraySet1[1][1] + arraySet1[2][1]);
	// console.log(arraySet1[0][2] + arraySet1[1][2] + arraySet1[2][2]);
	// console.log("Final count = x" + xAxis + ", y" + yAxis);
	
	// console.log(arraySet1[0,0]);
	// console.log(arraySet1[1,0]);
	// console.log(arraySet1[2,0]);

	// console.log(arraySet1[0,1]);
	// console.log(arraySet1[1,1]);
	// console.log(arraySet1[2,1]);	

	// console.log(arraySet1[0,2]);
	// console.log(arraySet1[1,2]);
	// console.log(arraySet1[2,2]);

	// console.dir("a = " + arraySet1[6,6]);
}

var kesLoop2 = function() {
	function editorCreateModel2DTemplate(){
	    var arr2d = [];
	        for (var y=0; y<22; y++){
	            var arr1d = [];
	            for (var x=0; x<10; x++){
	                arr1d.push('aaa');
	            }
	            arr2d.push(arr1d);
	        }

	    return(arr2d);
	}
}



 // var array1 = [0,0,0,0,0,0,0,0,0,0], [0,0,0,0,0,0,0,0,0,0], [0,0,0,0,0,0,0,0,0,0];



 console.dir(arraySet1);
