/*To do:
	- Generate grid in the dom ("main_grid")
		- Using a for loop with incremented numbers
		- will need to use an 'attribute selector' in css
	
	- Movement:
		- user to be able to move pieces L/R
		- user to be able to rotate pieces CW/CCW
		
	- Make a counter (for movement beats / rate of play)
		- Pieces move every beat
		- Pieces stop when their bottom edge touches something
			- Another piece, or the bottom
	Line disappears when 
	
	- Define piece shapes
	- Random piece generater
		- should have a 'next piece preview', so have the generator take a step back

	- Scoreboard (every line cleared)

*/


var arraySet1 = new Array(10); //new array with ten undefined elements



var setUpGrid = function() {
	
	

	// for (var i = 0; i < 10; i++) {
	//   arraySet1[i] = new Array(22); //adds an array with 22 values in each
	// };

	for (var p1 = 0; p1 < 10; p1++) {  // Gives everything in array a value of 0
		for (var p2 = 0; p2 < 22; p2++) {
			arraySet1[p1,p2] = 0;
			console.log(arraySet1[p1,p2]);
			// console.log("p1 = " + p1 + ", p2 =" + p2)
		};
	};

}

var fillOutGrid = function() {
	console.dir(arraySet1);
	for (var p1 = 0; p1 < 10; p1++) {  // Gives everything in array a value of 0
		for (var p2 = 0; p2 < 22; p2++) {
			console.log(arraySet1[p1,p2]);
			// if (arraySet1[p1,p2] === 0) {
			// 	document.getElementById("cell" + p1 + p2).setAttribute("background-color", "red");
			// 	console.log("it was zero");
			// } else {
			// 	document.getElementById("cell" + p1 + p2).setAttribute("background-color", "blue");
			// 	console.log("it was one");
			// }
		}
	}
}

var kesLoop = function() {

	var div1Js = document.createElement('div1HT');
		document.body.appendChild(div1HT);
		myArray.push(div1HT);
}



var newLoopForTrial = function() { //set up divs for each cell of arraySet1

	// var toAdd = document.createElement("addtohtml");
	var toAdd = document.getElementById("addtohtml1");
	for(var i=0; i < 11; i++){
	   
	   var toAddChild = document.createElement('div' + i);
	   toAddChild.id = 'r'+i;
	   toAddChild.className = "trial1";
	   toAddChild.setAttribute("style", "left:" + i*51 + "px;");
	   toAdd.appendChild(toAddChild);
	   console.log("i = " + i);
	}
	
	console.log(toAdd);
	console.dir(toAdd);
	// document.appendChild(toAdd);

}









var start = function() {
	setUpGrid();
	fillOutGrid();
	newLoopForTrial();
}

// x[5][12] = 3.0; //enter values into the arrays






 // var array1 = [0,0,0,0,0,0,0,0,0,0], [0,0,0,0,0,0,0,0,0,0], [0,0,0,0,0,0,0,0,0,0];



 console.dir(arraySet1);
